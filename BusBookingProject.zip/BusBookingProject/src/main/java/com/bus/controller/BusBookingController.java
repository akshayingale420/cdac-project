/**
 * 
 */
package com.bus.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bus.model.Bus;
import com.bus.model.Driver;
import com.bus.model.Passenger;
import com.bus.model.User;
import com.bus.pojo.TicketBookingDTO;
import com.bus.service.BusService;
import com.bus.service.UserService;


@Controller
public class BusBookingController {

	@Autowired
	BusService busService;
	

	@Autowired
	UserService userService;
	
	@RequestMapping("/")
	public String indexPage() {
		return "index";//actual view name : /WEB-INF/views/index.jsp
	}

	@RequestMapping(value="/addBus", method = RequestMethod.GET)
	public String addBusPage(ModelMap model) {
		
		model.addAttribute("bus", new Bus());
       
        return "addBus";
	}

	@RequestMapping(value="/addBusDetail", method = RequestMethod.POST)
	public String addBusDetailPage(Bus bus, ModelMap model, HttpSession session) {

		User user=(User) session.getAttribute("userDtl");
		bus.setUser(user);
        Bus busDtl = busService.addBusDetail(bus);

        if (busDtl == null) {
            model.put("errorMessage", " Error While Insertung Bus Record. ");
            return "redirect:/addBus";
        }else {
        	return "redirect:/busReport";
        }
	}

	@RequestMapping(value="/addDriver", method = RequestMethod.GET)
	public String addDriverPage(ModelMap model) {
		
		model.addAttribute("driver", new Driver());
		model.addAttribute("busList", busService.busDetail());
        return "addDriver";
	}
	
	@RequestMapping(value="/addDriverDetail", method = RequestMethod.POST)
	public String addDriverDetailPage(Driver driver, ModelMap model, HttpSession session) {

		User user=(User) session.getAttribute("userDtl");
		driver.setUser(user);
        Driver driverDtl = busService.addDriverDetail(driver);

        if (driverDtl == null) {
            model.put("errorMessage", " Error While Insertung Bus Record. ");
            return "redirect:/addDriver";
        }else {
        	return "redirect:/busReport";
        }
	}
	
	
	@RequestMapping(value="/busReport", method = RequestMethod.GET)
	public String busReportPage(ModelMap model) {
		
        List<Bus> busList = busService.busDetail();

        model.addAttribute("busList", busList);
        return "busReport";
	}
	@RequestMapping(value="/driverDetail", method = RequestMethod.GET)
	public String driverDetailPage(ModelMap model,@RequestParam Long busId ) {
		
        List<Driver> driverList = busService.driverDetail(busId);

        model.addAttribute("driverList", driverList);
        return "driverDetail";
	}
	@RequestMapping(value="/deleteBus", method = RequestMethod.GET)
	public String deleteBus(@RequestParam long busId, HttpSession session) {
		System.out.println("in delete bus");
		String message =busService.deleteBus(busId);
		return "redirect:/busReport";
	}
	

	@RequestMapping(value="/bookTicket", method = RequestMethod.GET)
	public String bookTicket(Model model, @RequestParam(required = false) String busId) {
		
		//List<Bus> busList = busService.busDetail();
		model.addAttribute("selectedBusId",busId);
        model.addAttribute("ticketBookingDTO", new TicketBookingDTO());
        return "bookTicket";
	}
	
	@RequestMapping(value="/bookTicketDtl", method = RequestMethod.POST)
	public String bookTicketDtl(ModelMap model, TicketBookingDTO ticketBookingDTO, HttpSession session) {
		if(ticketBookingDTO!=null) {
			Long successFlag= busService.payBookTicket(ticketBookingDTO,session);
			if(successFlag!=null) {
				Long passengerId=successFlag;
				//show
				
				model.put("successMessgae", "Thank You..! booking details Added successfully = "+passengerId);
				model.put("ticketBookingDTO",ticketBookingDTO);
				
				
				return "ticketBookingPaymentDetail";
			}else {
				model.put("errorMessage", " Error While Booking Ticket. ");
				model.addAttribute("selectedBusId",ticketBookingDTO.getSelectedBusId());
	            return "redirect:/bookTicket";
			}
		}else {
			model.put("errorMessage", " Error While Booking Ticket. ");
			model.addAttribute("selectedBusId",ticketBookingDTO.getSelectedBusId());
            return "redirect:/bookTicket";
		}
        //model.addAttribute("busList", busList);
        
	}

	@RequestMapping(value="/ticketHistory", method = RequestMethod.GET)
	public String ticketHistoryPage(ModelMap model, @RequestParam(required = false) String userId) {
		

        List<Passenger> ticketBookingDTOList = busService.getTicketBookingDetailList();

        model.addAttribute("ticketBookingDTOList", ticketBookingDTOList);
        return "ticketHistory";
	}
	
}
